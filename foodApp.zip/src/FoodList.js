import React from 'react';
import { Link } from 'react-router-dom';

function FoodList(props) {
  const { foods } = props;

  return (
    <div>
      <h2>Food List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Max Delivery Time (in minutes)</th>
          </tr>
        </thead>
        <tbody>
          {foods.map((food) => (
            <tr key={food.id}>
              <td>{food.name}</td>
              <td>{food.type}</td>
              <td>{food.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <Link to="/filter">Filter Foods</Link>
    </div>
  );
}

export default FoodList;
