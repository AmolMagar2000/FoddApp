import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Link, Routes } from 'react-router-dom';

//import { BrowserRouter as  Route, Link, Routes, BrowserRouter } from 'react-router-dom';
import FoodList from './FoodList';
import FoodForm from './FoodForm';
import FoodFilter from './FoodFilter';

function App() {
  const [foods, setFoods] = useState([]);

  useEffect(() => {
    const storedFoods = JSON.parse(localStorage.getItem('foods'));
    if (storedFoods) {
      setFoods(storedFoods);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('foods', JSON.stringify(foods));
  }, [foods]);

  function addFood(newFood) {
    setFoods([...foods, newFood]);
  }

  return (
    <BrowserRouter>
      <Routes>
        <>
          <nav>
            <ul>
              <li>
                <Link to="/">Food List</Link>
              </li>
              <li>
                <Link to="/add-food">Add Food</Link>
              </li>
              <li>
                <Link to="/filter-food">Filter Food</Link>
              </li>
            </ul>
          </nav>

          <Route exact path="/">
            <FoodList foods={foods} />
          </Route>
          <Route path="/add-food">
            <FoodForm addFood={addFood} />
          </Route>
          <Route path="/filter-food">
            <FoodFilter foods={foods} />
          </Route>
        </>
      </Routes>
    </BrowserRouter>
  );
}

export default App;


