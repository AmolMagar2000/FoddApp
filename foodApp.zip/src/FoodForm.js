import React, { useState } from 'react';
import { v4 as uuid } from 'uuid';

function FoodForm(props) {
  const [name, setName] = useState('');
  const [type, setType] = useState('Delicious Food');
  const [time, setTime] = useState(0);

  const handleSubmit = (event) => {
    event.preventDefault();
    const id = uuid();
    const food = { id, name, type, time };
    props.onSubmit(food);
    setName('');
    setType('Delicious Food');
    setTime(0);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="name">Food Name:</label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(event) => setName(event.target.value)}
        />
      </div>
      <div>
        <label htmlFor="type">Food Type:</label>
        <select
          id="type"
          value={type}
          onChange={(event) => setType(event.target.value)}
        >
          <option value="Delicious Food">Delicious Food</option>
          <option value="Nutritious Food">Nutritious Food</option>
          <option value="Fast Food">Fast Food</option>
          <option value="Beverages">Beverages</option>
          <option value="Desserts">Desserts</option>
        </select>
      </div>
      <div>
        <label htmlFor="time">Max Delivery Time (in minutes):</label>
        <input
          type="number"
          id="time"
          value={time}
          onChange={(event) => setTime(parseInt(event.target.value))}
        />
      </div>
      <button type="submit">Submit</button>
    </form>
  );
}

export default FoodForm;
