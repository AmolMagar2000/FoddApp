import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function FoodFilter(props) {
  const { foods } = props;
  const [typeFilter, setTypeFilter] = useState('');
  const [timeFilter, setTimeFilter] = useState('');

  const filteredFoods = foods.filter((food) => {
    if (typeFilter && food.type !== typeFilter) {
      return false;
    }
    if (timeFilter && food.time > parseInt(timeFilter)) {
      return false;
    }
    return true;
  });

  return (
    <div>
      <h2>Filtered Food List</h2>
      <div>
        <label htmlFor="typeFilter">Filter by Type:</label>
        <select
          id="typeFilter"
          value={typeFilter}
          onChange={(event) => setTypeFilter(event.target.value)}
        >
          <option value="">All</option>
          <option value="Delicious Food">Delicious Food</option>
          <option value="Nutritious Food">Nutritious Food</option>
          <option value="Fast Food">Fast Food</option>
          <option value="Beverages">Beverages</option>
          <option value="Desserts">Desserts</option>
        </select>
      </div>
      <div>
        <label htmlFor="timeFilter">Filter by Max Delivery Time (in minutes):</label>
        <input
          type="number"
          id="timeFilter"
          value={timeFilter}
          onChange={(event) => setTimeFilter(event.target.value)}
        />
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Max Delivery Time (in minutes)</th>
          </tr>
        </thead>
        <tbody>
          {filteredFoods.map((food) => (
            <tr key={food.id}>
              <td>{food.name}</td>
              <td>{food.type}</td>
              <td>{food.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <Link to="/">Back to Food List</Link>
    </div>
  );
}

export default FoodFilter;
